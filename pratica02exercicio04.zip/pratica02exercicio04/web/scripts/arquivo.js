function enviar () {
     return confirm ("Deseja realmente enviar essa preferência para o servlet?");
}

